CompactChests
=============

Making chests, compact!
